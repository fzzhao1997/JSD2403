package OOday01.work.two;

public class CarTest {
    public static void main(String[] args) {
        Car cr = new Car("小米",9.9,"黑色");
        cr.start();
        cr.run();
        cr.stop();
    }
}
