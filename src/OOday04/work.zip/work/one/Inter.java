package OOday04.work.one;

public interface Inter {
    void show();
}
