package OOday04.work.one;

interface Swim {
    void swim();
}
