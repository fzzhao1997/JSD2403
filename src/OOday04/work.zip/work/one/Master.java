package OOday04.work.one;

public class Master {
    Master(){}
    void feed(Animal animal){
        animal.eat();
    }
}
