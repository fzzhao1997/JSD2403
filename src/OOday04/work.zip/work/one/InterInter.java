package OOday04.work.one;

public interface InterInter {
    void show();
}
