package OOday04.work.two;

public interface Swim {
    void swim();
}
