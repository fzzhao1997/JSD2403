package OOday04.work.two;

public class Master {
    Master(){}
    void feed(Animal animal){
        animal.eat();
    }
}
